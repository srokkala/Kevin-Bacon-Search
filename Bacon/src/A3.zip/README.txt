
Running on Command Line Instructions:
TO COMPILE: javac -cp .:json-simple-1.1.1.jar:opencsv-4.6.jar:commons-lang3-3.9.jar *java 

TO RUN: java -cp .:json-simple-1.1.1.jar:opencsv-4.6.jar:commons-lang3-3.9.jar Kevin tmdb_5000_credits.csv


All .jar files and .csv file and .java files are in the same folder


I have used OPENCSV as my CSV parser, SimpleJSON, and Commons Lang

CommonsLang.jar can be found at this site:
https://commons.apache.org/proper/commons-lang/download_lang.cgi

OpenCSV.jar can be found at:
https://sourceforge.net/projects/opencsv/










